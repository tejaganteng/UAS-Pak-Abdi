package com.example.katalogmovie.Config;

public class ServerConfig {
    public static final String URL_BASE = "https://api.themoviedb.org/";
    public static final String API_ENDPOINT=URL_BASE;


}
